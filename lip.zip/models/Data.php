<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "data".
 *
 * @property int $id
 * @property int $code
 * @property int $name
 * @property int $card
 * @property int $discount
 * @property string $user_name
 * @property string $gender
 * @property int $age
 * @property int $born_year
 * @property string $born_date
 * @property string $email
 * @property string $phone
 * @property string $comment
 * @property string $subscribe
 */
class Data extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'data';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'name', 'card', 'discount', 'user_name', 'age', 'born_year', 'born_date', 'email', 'phone', 'comment'], 'required'],
            [['code', 'name', 'card', 'discount', 'age', 'born_year'], 'integer'],
            [['user_name', 'gender', 'comment', 'subscribe'], 'string'],
            [['born_date'], 'safe'],
            [['email', 'phone'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'code' => 'Код',
            'name' => 'Наименование',
            'card' => 'Номер карты',
            'discount' => 'Скидка',
            'user_name' => 'Имя клиента',
            'gender' => 'Пол',
            'age' => 'Возраст',
            'born_year' => 'Год рождения',
            'born_date' => 'Дата рождения',
            'email' => 'Email',
            'phone' => 'Телефон',
            'comment' => 'Комментарий',
            'subscribe' => 'Подписка на рассылку',
        ];
    }
}
